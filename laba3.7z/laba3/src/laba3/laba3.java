package laba3;

import java.util.*;

public class laba3 
{
	public static void main(String[] str) 
	{
		Scanner in=null;
		int v=10;
		while(v!=0)
		{
			try
			{
				in=new Scanner(System.in);
				System.out.println("[1]Work with class(Meteorological observations)");
				System.out.println("[2]Work with database(Luggage room)");
				System.out.println("[~]Exit");
				v=in.nextInt();
				switch(v)
				{
					case 1:one();break;
					case 2:two();break;
					case 3:break;
				}
			}
			catch(Exception ex) {System.out.print("Invalid data format!");};
		}
	
	}

	public static void one()
	{
		mounth mas[]=new mounth[12];
		mounth january=new mounth();
		mas[0]=january;
		mounth february=new mounth();
		mas[1]=february;
		mounth marth=new mounth();
		mas[2]=marth;
		mounth april=new mounth();
		mas[3]=april;
		mounth may=new mounth();
		mas[4]=may;
		mounth june=new mounth();
		mas[5]=june;
		mounth july=new mounth();
		mas[6]=july;
		mounth august=new mounth();
		mas[7]=august;
		mounth october=new mounth();
		mas[8]=october;
		mounth september=new mounth();
		mas[9]=september;
		mounth november=new mounth();
		mas[10]=november;
		mounth december=new mounth();
		mas[11]=december;
		Scanner in2=new Scanner(System.in);
		int v1=10;
		while(v1!=0)
		{
			System.out.println("[1]Fill in randomly");
			System.out.println("[2]Fill in from the keyboard");
			System.out.println("[~]Exit");
			v1=in2.nextInt();
			switch(v1)
			{
				case 1:january.Zap_rand(1);february.Zap_rand(2);marth.Zap_rand(3);april.Zap_rand(4);may.Zap_rand(5);june.Zap_rand(6);july.Zap_rand(7);august.Zap_rand(8);october.Zap_rand(9);september.Zap_rand(10);november.Zap_rand(11);december.Zap_rand(12);mounth.toBig(mas);break;
				case 2:january.zap_klava(1);february.zap_klava(2);marth.zap_klava(3);april.zap_klava(4);may.zap_klava(5);june.zap_klava(6);july.zap_klava(7);august.zap_klava(8);october.zap_klava(9);september.zap_klava(10);november.zap_klava(11);december.zap_klava(12);mounth.toBig(mas);break;
				case 0: break;
			}
		}
	}

	public static void two()
	{
		kamera_showu.start();
		kamera_showu km;
		Scanner in=null;
		String v="";
		while(v!="Exit")
		{
			try
			{
				in=new Scanner(System.in);
				System.out.println("\n[1]Add/Edit");
				System.out.println("[2]Print");
				System.out.println("[3]Delete");
				System.out.println("[4]Search");
				System.out.println("[~]Exit");
				v=in.nextLine();
				switch(v)
				{
					case "1":kamera_showu.add(); ;break;
					case "2":kamera_showu.show(); ;break;
					case "3":kamera_showu.delete(); break;
					case "4":kamera_showu.search();break;
					default: System.out.print("Error value");
				}
			}
			catch(Exception ex) {System.out.print("Invalid data format!");};
		}
	};
}
